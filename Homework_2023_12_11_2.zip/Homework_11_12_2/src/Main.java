public class Main {
    public static void main(String[] args) {
        //Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
        // т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.
        String input = "AAAABBBCCCDDEG";
        String result = compressString(input);
        System.out.println(result); // Выводит: A4B3C3D2EG
    }

    public static String compressString(String input) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i = 0; i < input.length(); i++) {
            // Если текущий символ равен следующему
            if (i + 1 < input.length() && input.charAt(i) == input.charAt(i + 1)) {
                count++;
            } else {
                // Если текущий символ не равен следующему
                sb.append(input.charAt(i));
                // Если буква повторяется больше одного раза, добавляем количество
                if (count > 1) {
                    sb.append(count);
                }
                count = 1; // Сброс счетчика
            }
        }
        return sb.toString();
    }
}



