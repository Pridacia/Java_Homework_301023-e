import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Программа генерирует два целых однозначных числа.
        // Программа задаёт вопрос: результат умножения первого числа на второе?
        //  Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        Random rnd = new Random();
        Scanner scr = new Scanner(System.in);
        int num1 = rnd.nextInt(0,10);
        int num2 = rnd.nextInt(0,10);
        int  correctAnswer = num1 * num2;
        System.out.println("Результат первого числа на второе " + num1 + " умножить на " + num2);
        int userAnswer = scr.nextInt();
        if (userAnswer ==correctAnswer) {
            System.out.println("Верный ответ");
        } else {
            System.out.println("Неверно.Верныйный ответ: " + correctAnswer);
        }

    }
}