public class Main {
    public static void main(String[] args) {
        //Создайте строку через new - I study Basic Java!
        //Напишите метод, который принимает в качестве параметра строку, передайте в этот метод созданную строку
        //Распечатать последний символ строки. Используем метод String.charAt().
        //Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        //Заменить все символы “а” на “о”.
        //Преобразуйте строку к верхнему регистру.
        //Преобразуйте строку к нижнему регистру.
        //Вырезать строку Java c помощью метода String.substring().

        String str = new String("I stydy Basic Java");
        printLastChar(str);
        checkSubstring(str);
        replaceCharacters(str);
        convertToUpperCase(str);
        convertToLowerCase(str);
        cutSubstring(str);
    }

    public static void printLastChar(String str) {
        char lastChar = str.charAt(str.length() - 1);
        System.out.println("Последний символ строки: " + lastChar);
    }

    public static void checkSubstring(String str) {
        boolean containsSubstring = str.contains("Java");
        System.out.println("Строка содержит подстроку 'Java': " + containsSubstring);
    }

    public static void replaceCharacters(String str) {
        String replacedStr = str.replace('a', 'o');
        System.out.println("Строка после замены символов: " + replacedStr);
    }

    public static void convertToUpperCase(String str) {
        String upperCaseStr = str.toUpperCase();
        System.out.println("Строка в верхнем регистре: " + upperCaseStr);
    }

    public static void convertToLowerCase(String str) {
        String lowerCaseStr = str.toLowerCase();
        System.out.println("Строка в нижнем регистре: " + lowerCaseStr);
    }

    public static void cutSubstring(String str) {
        String cutStr = str.substring(0, str.indexOf("Java"));
        System.out.println("Строка после вырезания подстроки 'Java': " + cutStr);
    }

}

