import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества
        // букв (проверьте количество букв в слове).
        //Нужно получить слово, состоящее из первой половины первого слова
        // и второй половины второго слова. распечатать на консоль.
        //Например: ввод - mama, papa. Вывод – mapa

        Scanner scr = new Scanner(System.in);
        System.out.print("Введите первое слово: ");
        String word1 = scr.nextLine();
        System.out.print("Введите второе слово: ");
        String word2 = scr.nextLine();

        if (word1.length() % 2 == 0 && word2.length() % 2 == 0) {
            String result = word1.substring(0, word1.length() / 2) + word2.substring(word2.length() / 2);
            System.out.println("Результат: " + result);
        } else {
            System.out.println("Ошибка! Оба слова должны иметь четное количество букв.");
        }
    }
}

