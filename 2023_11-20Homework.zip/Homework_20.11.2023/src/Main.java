import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //уровень сложности: №1 Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например :
        //ввод : m=16, n=12
        //вывод: Число 12 ближе к 10.
        Scanner scr = new Scanner(System.in);
        int m = 16;
        int n = 12;
        int xn = Math.abs(10 - n);
        int xm = Math.abs(10 - m);
        if (xn < xm) {
            System.out.println("Число " + n + " ближе к 10");

        }
    }
}